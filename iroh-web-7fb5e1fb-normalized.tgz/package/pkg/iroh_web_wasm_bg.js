/**
 * An established QUIC connection to a remote endpoint.
 */
export class Connection {
    static __wrap(ptr) {
        const obj = Object.create(Connection.prototype);
        obj.__wbg_ptr = ptr;
        ConnectionFinalization.register(obj, obj.__wbg_ptr, obj);
        return obj;
    }
    __destroy_into_raw() {
        const ptr = this.__wbg_ptr;
        this.__wbg_ptr = 0;
        ConnectionFinalization.unregister(this);
        return ptr;
    }
    free() {
        const ptr = this.__destroy_into_raw();
        wasm.__wbg_connection_free(ptr, 0);
    }
    /**
     * Accepts the next bidirectional stream opened by the remote.
     * @returns {Promise<[WritableStream<Uint8Array>, ReadableStream<Uint8Array>]>}
     */
    acceptBi() {
        const ret = wasm.connection_acceptBi(this.__wbg_ptr);
        return takeObject(ret);
    }
    /**
     * Accepts the next unidirectional (receive-only) stream opened by the remote.
     * @returns {Promise<ReadableStream<Uint8Array>>}
     */
    acceptUni() {
        const ret = wasm.connection_acceptUni(this.__wbg_ptr);
        return takeObject(ret);
    }
    /**
     * The ALPN negotiated for this connection.
     * @returns {Uint8Array}
     */
    alpn() {
        try {
            const retptr = wasm.__wbindgen_add_to_stack_pointer(-16);
            wasm.connection_alpn(retptr, this.__wbg_ptr);
            var r0 = getDataViewMemory0().getInt32(retptr + 4 * 0, true);
            var r1 = getDataViewMemory0().getInt32(retptr + 4 * 1, true);
            var v1 = getArrayU8FromWasm0(r0, r1).slice();
            wasm.__wbindgen_export4(r0, r1 * 1, 1);
            return v1;
        } finally {
            wasm.__wbindgen_add_to_stack_pointer(16);
        }
    }
    /**
     * Closes the connection immediately with an application error code and reason.
     * @param {number} error_code
     * @param {Uint8Array} reason
     */
    close(error_code, reason) {
        const ptr0 = passArray8ToWasm0(reason, wasm.__wbindgen_export);
        const len0 = WASM_VECTOR_LEN;
        wasm.connection_close(this.__wbg_ptr, error_code, ptr0, len0);
    }
    /**
     * Resolves with an `Error` (carrying a `code` property) describing why the
     * connection closed, once it has closed.
     * @returns {Promise<Error>}
     */
    closed() {
        const ret = wasm.connection_closed(this.__wbg_ptr);
        return takeObject(ret);
    }
    /**
     * Opens a bidirectional stream. Resolves with `[WritableStream, ReadableStream]`.
     * @returns {Promise<[WritableStream<Uint8Array>, ReadableStream<Uint8Array>]>}
     */
    openBi() {
        const ret = wasm.connection_openBi(this.__wbg_ptr);
        return takeObject(ret);
    }
    /**
     * Opens a unidirectional (send-only) stream.
     * @returns {Promise<WritableStream<Uint8Array>>}
     */
    openUni() {
        const ret = wasm.connection_openUni(this.__wbg_ptr);
        return takeObject(ret);
    }
    /**
     * Hex-encoded id of the remote endpoint.
     * @returns {string}
     */
    remoteId() {
        let deferred1_0;
        let deferred1_1;
        try {
            const retptr = wasm.__wbindgen_add_to_stack_pointer(-16);
            wasm.connection_remoteId(retptr, this.__wbg_ptr);
            var r0 = getDataViewMemory0().getInt32(retptr + 4 * 0, true);
            var r1 = getDataViewMemory0().getInt32(retptr + 4 * 1, true);
            deferred1_0 = r0;
            deferred1_1 = r1;
            return getStringFromWasm0(r0, r1);
        } finally {
            wasm.__wbindgen_add_to_stack_pointer(16);
            wasm.__wbindgen_export4(deferred1_0, deferred1_1, 1);
        }
    }
}
if (Symbol.dispose) Connection.prototype[Symbol.dispose] = Connection.prototype.free;

/**
 * A bound iroh endpoint.
 *
 * All async operations return promises and internally work on a clone of the
 * iroh endpoint, so any number of them can be in flight at once.
 */
export class Endpoint {
    static __wrap(ptr) {
        const obj = Object.create(Endpoint.prototype);
        obj.__wbg_ptr = ptr;
        EndpointFinalization.register(obj, obj.__wbg_ptr, obj);
        return obj;
    }
    __destroy_into_raw() {
        const ptr = this.__wbg_ptr;
        this.__wbg_ptr = 0;
        EndpointFinalization.unregister(this);
        return ptr;
    }
    free() {
        const ptr = this.__destroy_into_raw();
        wasm.__wbg_endpoint_free(ptr, 0);
    }
    /**
     * Waits for the next incoming connection.
     *
     * Resolves with `undefined` once the endpoint is closed. Incoming
     * connections whose handshake fails are logged and skipped.
     * @returns {Promise<Connection | undefined>}
     */
    accept() {
        const ret = wasm.endpoint_accept(this.__wbg_ptr);
        return takeObject(ret);
    }
    /**
     * The current address (id plus known relay URLs). Call `online()` first
     * to make sure a relay URL is included.
     * @returns {EndpointAddr}
     */
    addr() {
        const ret = wasm.endpoint_addr(this.__wbg_ptr);
        return EndpointAddr.__wrap(ret);
    }
    /**
     * Binds an endpoint that resolves peer addresses over HTTPS pkarr without publishing its own.
     * @param {Uint8Array | null | undefined} secret_key
     * @param {Uint8Array[]} alpns
     * @param {string[] | null} [relay_urls]
     * @returns {Promise<Endpoint>}
     */
    static bindLookupOnly(secret_key, alpns, relay_urls) {
        var ptr0 = isLikeNone(secret_key) ? 0 : passArray8ToWasm0(secret_key, wasm.__wbindgen_export);
        var len0 = WASM_VECTOR_LEN;
        var ptr1 = isLikeNone(relay_urls) ? 0 : passArrayJsValueToWasm0(relay_urls, wasm.__wbindgen_export);
        var len1 = WASM_VECTOR_LEN;
        const ret = wasm.endpoint_bindLookupOnly(ptr0, len0, addHeapObject(alpns), ptr1, len1);
        return takeObject(ret);
    }
    /**
     * Binds a new endpoint.
     *
     * * `secret_key`: 32 raw bytes, or `undefined` to generate one.
     * * `alpns`: the ALPNs to accept incoming connections for.
     * * `relay_urls`: relay servers to use. `undefined` selects n0's public
     *   relays plus pkarr address publishing (the `N0` preset). When given,
     *   only those relays are used and no address lookup service is configured.
     * @param {Uint8Array | null | undefined} secret_key
     * @param {Uint8Array[]} alpns
     * @param {string[] | null} [relay_urls]
     * @returns {Promise<Endpoint>}
     */
    static bind(secret_key, alpns, relay_urls) {
        var ptr0 = isLikeNone(secret_key) ? 0 : passArray8ToWasm0(secret_key, wasm.__wbindgen_export);
        var len0 = WASM_VECTOR_LEN;
        var ptr1 = isLikeNone(relay_urls) ? 0 : passArrayJsValueToWasm0(relay_urls, wasm.__wbindgen_export);
        var len1 = WASM_VECTOR_LEN;
        const ret = wasm.endpoint_bind(ptr0, len0, addHeapObject(alpns), ptr1, len1);
        return takeObject(ret);
    }
    /**
     * Closes the endpoint and all its connections.
     * @returns {Promise<void>}
     */
    close() {
        const ret = wasm.endpoint_close(this.__wbg_ptr);
        return takeObject(ret);
    }
    /**
     * Connects to a remote endpoint with the given ALPN.
     * @param {EndpointAddr} addr
     * @param {Uint8Array} alpn
     * @returns {Promise<Connection>}
     */
    connect(addr, alpn) {
        _assertClass(addr, EndpointAddr);
        const ptr0 = passArray8ToWasm0(alpn, wasm.__wbindgen_export);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.endpoint_connect(this.__wbg_ptr, addr.__wbg_ptr, ptr0, len0);
        return takeObject(ret);
    }
    /**
     * The hex-encoded endpoint id.
     * @returns {string}
     */
    id() {
        let deferred1_0;
        let deferred1_1;
        try {
            const retptr = wasm.__wbindgen_add_to_stack_pointer(-16);
            wasm.endpoint_id(retptr, this.__wbg_ptr);
            var r0 = getDataViewMemory0().getInt32(retptr + 4 * 0, true);
            var r1 = getDataViewMemory0().getInt32(retptr + 4 * 1, true);
            deferred1_0 = r0;
            deferred1_1 = r1;
            return getStringFromWasm0(r0, r1);
        } finally {
            wasm.__wbindgen_add_to_stack_pointer(16);
            wasm.__wbindgen_export4(deferred1_0, deferred1_1, 1);
        }
    }
    /**
     * Whether `close()` has been called.
     * @returns {boolean}
     */
    isClosed() {
        const ret = wasm.endpoint_isClosed(this.__wbg_ptr);
        return ret !== 0;
    }
    /**
     * Resolves once the endpoint has a working connection to a home relay.
     * @returns {Promise<void>}
     */
    online() {
        const ret = wasm.endpoint_online(this.__wbg_ptr);
        return takeObject(ret);
    }
}
if (Symbol.dispose) Endpoint.prototype[Symbol.dispose] = Endpoint.prototype.free;

/**
 * An endpoint id plus the relay URLs it can be reached through.
 */
export class EndpointAddr {
    static __wrap(ptr) {
        const obj = Object.create(EndpointAddr.prototype);
        obj.__wbg_ptr = ptr;
        EndpointAddrFinalization.register(obj, obj.__wbg_ptr, obj);
        return obj;
    }
    __destroy_into_raw() {
        const ptr = this.__wbg_ptr;
        this.__wbg_ptr = 0;
        EndpointAddrFinalization.unregister(this);
        return ptr;
    }
    free() {
        const ptr = this.__destroy_into_raw();
        wasm.__wbg_endpointaddr_free(ptr, 0);
    }
    /**
     * Parses an `endpoint…` ticket string (as produced by [`EndpointAddr::to_ticket`]).
     * @param {string} ticket
     * @returns {EndpointAddr}
     */
    static fromTicket(ticket) {
        try {
            const retptr = wasm.__wbindgen_add_to_stack_pointer(-16);
            const ptr0 = passStringToWasm0(ticket, wasm.__wbindgen_export, wasm.__wbindgen_export2);
            const len0 = WASM_VECTOR_LEN;
            wasm.endpointaddr_fromTicket(retptr, ptr0, len0);
            var r0 = getDataViewMemory0().getInt32(retptr + 4 * 0, true);
            var r1 = getDataViewMemory0().getInt32(retptr + 4 * 1, true);
            var r2 = getDataViewMemory0().getInt32(retptr + 4 * 2, true);
            if (r2) {
                throw takeObject(r1);
            }
            return EndpointAddr.__wrap(r0);
        } finally {
            wasm.__wbindgen_add_to_stack_pointer(16);
        }
    }
    /**
     * The hex-encoded endpoint id.
     * @returns {string}
     */
    id() {
        let deferred1_0;
        let deferred1_1;
        try {
            const retptr = wasm.__wbindgen_add_to_stack_pointer(-16);
            wasm.endpointaddr_id(retptr, this.__wbg_ptr);
            var r0 = getDataViewMemory0().getInt32(retptr + 4 * 0, true);
            var r1 = getDataViewMemory0().getInt32(retptr + 4 * 1, true);
            deferred1_0 = r0;
            deferred1_1 = r1;
            return getStringFromWasm0(r0, r1);
        } finally {
            wasm.__wbindgen_add_to_stack_pointer(16);
            wasm.__wbindgen_export4(deferred1_0, deferred1_1, 1);
        }
    }
    /**
     * Builds an address from a hex endpoint id and zero or more relay URLs.
     * @param {string} id
     * @param {string[]} relay_urls
     */
    constructor(id, relay_urls) {
        try {
            const retptr = wasm.__wbindgen_add_to_stack_pointer(-16);
            const ptr0 = passStringToWasm0(id, wasm.__wbindgen_export, wasm.__wbindgen_export2);
            const len0 = WASM_VECTOR_LEN;
            const ptr1 = passArrayJsValueToWasm0(relay_urls, wasm.__wbindgen_export);
            const len1 = WASM_VECTOR_LEN;
            wasm.endpointaddr_new(retptr, ptr0, len0, ptr1, len1);
            var r0 = getDataViewMemory0().getInt32(retptr + 4 * 0, true);
            var r1 = getDataViewMemory0().getInt32(retptr + 4 * 1, true);
            var r2 = getDataViewMemory0().getInt32(retptr + 4 * 2, true);
            if (r2) {
                throw takeObject(r1);
            }
            this.__wbg_ptr = r0;
            EndpointAddrFinalization.register(this, this.__wbg_ptr, this);
            return this;
        } finally {
            wasm.__wbindgen_add_to_stack_pointer(16);
        }
    }
    /**
     * The relay URLs contained in this address.
     * @returns {string[]}
     */
    relayUrls() {
        try {
            const retptr = wasm.__wbindgen_add_to_stack_pointer(-16);
            wasm.endpointaddr_relayUrls(retptr, this.__wbg_ptr);
            var r0 = getDataViewMemory0().getInt32(retptr + 4 * 0, true);
            var r1 = getDataViewMemory0().getInt32(retptr + 4 * 1, true);
            var v1 = getArrayJsValueFromWasm0(r0, r1);
            wasm.__wbindgen_export4(r0, r1 * 4, 4);
            return v1;
        } finally {
            wasm.__wbindgen_add_to_stack_pointer(16);
        }
    }
    /**
     * Serialises this address as a ticket string suitable for QR codes.
     * @returns {string}
     */
    toTicket() {
        let deferred1_0;
        let deferred1_1;
        try {
            const retptr = wasm.__wbindgen_add_to_stack_pointer(-16);
            wasm.endpointaddr_toTicket(retptr, this.__wbg_ptr);
            var r0 = getDataViewMemory0().getInt32(retptr + 4 * 0, true);
            var r1 = getDataViewMemory0().getInt32(retptr + 4 * 1, true);
            deferred1_0 = r0;
            deferred1_1 = r1;
            return getStringFromWasm0(r0, r1);
        } finally {
            wasm.__wbindgen_add_to_stack_pointer(16);
            wasm.__wbindgen_export4(deferred1_0, deferred1_1, 1);
        }
    }
}
if (Symbol.dispose) EndpointAddr.prototype[Symbol.dispose] = EndpointAddr.prototype.free;

export class IntoUnderlyingByteSource {
    __destroy_into_raw() {
        const ptr = this.__wbg_ptr;
        this.__wbg_ptr = 0;
        IntoUnderlyingByteSourceFinalization.unregister(this);
        return ptr;
    }
    free() {
        const ptr = this.__destroy_into_raw();
        wasm.__wbg_intounderlyingbytesource_free(ptr, 0);
    }
    /**
     * @returns {number}
     */
    get autoAllocateChunkSize() {
        const ret = wasm.intounderlyingbytesource_autoAllocateChunkSize(this.__wbg_ptr);
        return ret >>> 0;
    }
    cancel() {
        const ptr = this.__destroy_into_raw();
        wasm.intounderlyingbytesource_cancel(ptr);
    }
    /**
     * @param {ReadableByteStreamController} controller
     * @returns {Promise<any>}
     */
    pull(controller) {
        const ret = wasm.intounderlyingbytesource_pull(this.__wbg_ptr, addHeapObject(controller));
        return takeObject(ret);
    }
    /**
     * @param {ReadableByteStreamController} controller
     */
    start(controller) {
        wasm.intounderlyingbytesource_start(this.__wbg_ptr, addHeapObject(controller));
    }
    /**
     * @returns {ReadableStreamType}
     */
    get type() {
        const ret = wasm.intounderlyingbytesource_type(this.__wbg_ptr);
        return __wbindgen_enum_ReadableStreamType[ret];
    }
}
if (Symbol.dispose) IntoUnderlyingByteSource.prototype[Symbol.dispose] = IntoUnderlyingByteSource.prototype.free;

export class IntoUnderlyingSink {
    static __wrap(ptr) {
        const obj = Object.create(IntoUnderlyingSink.prototype);
        obj.__wbg_ptr = ptr;
        IntoUnderlyingSinkFinalization.register(obj, obj.__wbg_ptr, obj);
        return obj;
    }
    __destroy_into_raw() {
        const ptr = this.__wbg_ptr;
        this.__wbg_ptr = 0;
        IntoUnderlyingSinkFinalization.unregister(this);
        return ptr;
    }
    free() {
        const ptr = this.__destroy_into_raw();
        wasm.__wbg_intounderlyingsink_free(ptr, 0);
    }
    /**
     * @param {any} reason
     * @returns {Promise<any>}
     */
    abort(reason) {
        const ptr = this.__destroy_into_raw();
        const ret = wasm.intounderlyingsink_abort(ptr, addHeapObject(reason));
        return takeObject(ret);
    }
    /**
     * @returns {Promise<any>}
     */
    close() {
        const ptr = this.__destroy_into_raw();
        const ret = wasm.intounderlyingsink_close(ptr);
        return takeObject(ret);
    }
    /**
     * @param {any} chunk
     * @returns {Promise<any>}
     */
    write(chunk) {
        const ret = wasm.intounderlyingsink_write(this.__wbg_ptr, addHeapObject(chunk));
        return takeObject(ret);
    }
}
if (Symbol.dispose) IntoUnderlyingSink.prototype[Symbol.dispose] = IntoUnderlyingSink.prototype.free;

export class IntoUnderlyingSource {
    static __wrap(ptr) {
        const obj = Object.create(IntoUnderlyingSource.prototype);
        obj.__wbg_ptr = ptr;
        IntoUnderlyingSourceFinalization.register(obj, obj.__wbg_ptr, obj);
        return obj;
    }
    __destroy_into_raw() {
        const ptr = this.__wbg_ptr;
        this.__wbg_ptr = 0;
        IntoUnderlyingSourceFinalization.unregister(this);
        return ptr;
    }
    free() {
        const ptr = this.__destroy_into_raw();
        wasm.__wbg_intounderlyingsource_free(ptr, 0);
    }
    cancel() {
        const ptr = this.__destroy_into_raw();
        wasm.intounderlyingsource_cancel(ptr);
    }
    /**
     * @param {ReadableStreamDefaultController} controller
     * @returns {Promise<any>}
     */
    pull(controller) {
        const ret = wasm.intounderlyingsource_pull(this.__wbg_ptr, addHeapObject(controller));
        return takeObject(ret);
    }
}
if (Symbol.dispose) IntoUnderlyingSource.prototype[Symbol.dispose] = IntoUnderlyingSource.prototype.free;

/**
 * Generates a fresh ed25519 secret key and returns its 32 raw bytes.
 * @returns {Uint8Array}
 */
export function generateSecretKey() {
    try {
        const retptr = wasm.__wbindgen_add_to_stack_pointer(-16);
        wasm.generateSecretKey(retptr);
        var r0 = getDataViewMemory0().getInt32(retptr + 4 * 0, true);
        var r1 = getDataViewMemory0().getInt32(retptr + 4 * 1, true);
        var v1 = getArrayU8FromWasm0(r0, r1).slice();
        wasm.__wbindgen_export4(r0, r1 * 1, 1);
        return v1;
    } finally {
        wasm.__wbindgen_add_to_stack_pointer(16);
    }
}

/**
 * Routes iroh's `tracing` output to the browser console.
 *
 * `level` is one of `trace`, `debug`, `info`, `warn`, `error` or `off`.
 * Can only be called once per page load.
 * @param {string} level
 */
export function initLogging(level) {
    try {
        const retptr = wasm.__wbindgen_add_to_stack_pointer(-16);
        const ptr0 = passStringToWasm0(level, wasm.__wbindgen_export, wasm.__wbindgen_export2);
        const len0 = WASM_VECTOR_LEN;
        wasm.initLogging(retptr, ptr0, len0);
        var r0 = getDataViewMemory0().getInt32(retptr + 4 * 0, true);
        var r1 = getDataViewMemory0().getInt32(retptr + 4 * 1, true);
        if (r1) {
            throw takeObject(r0);
        }
    } finally {
        wasm.__wbindgen_add_to_stack_pointer(16);
    }
}

/**
 * Returns the endpoint id (hex-encoded public key) for a 32-byte secret key.
 * @param {Uint8Array} secret_key
 * @returns {string}
 */
export function secretKeyToId(secret_key) {
    let deferred3_0;
    let deferred3_1;
    try {
        const retptr = wasm.__wbindgen_add_to_stack_pointer(-16);
        const ptr0 = passArray8ToWasm0(secret_key, wasm.__wbindgen_export);
        const len0 = WASM_VECTOR_LEN;
        wasm.secretKeyToId(retptr, ptr0, len0);
        var r0 = getDataViewMemory0().getInt32(retptr + 4 * 0, true);
        var r1 = getDataViewMemory0().getInt32(retptr + 4 * 1, true);
        var r2 = getDataViewMemory0().getInt32(retptr + 4 * 2, true);
        var r3 = getDataViewMemory0().getInt32(retptr + 4 * 3, true);
        var ptr2 = r0;
        var len2 = r1;
        if (r3) {
            ptr2 = 0; len2 = 0;
            throw takeObject(r2);
        }
        deferred3_0 = ptr2;
        deferred3_1 = len2;
        return getStringFromWasm0(ptr2, len2);
    } finally {
        wasm.__wbindgen_add_to_stack_pointer(16);
        wasm.__wbindgen_export4(deferred3_0, deferred3_1, 1);
    }
}

export function start() {
    wasm.start();
}
export function __wbg___wbindgen_boolean_get_7a12af2b3f899c5a(arg0) {
    const v = getObject(arg0);
    const ret = typeof(v) === 'boolean' ? v : undefined;
    return isLikeNone(ret) ? 0xFFFFFF : ret ? 1 : 0;
}
export function __wbg___wbindgen_debug_string_0e68cf47c9cbd9b0(arg0, arg1) {
    const ret = debugString(getObject(arg1));
    const ptr1 = passStringToWasm0(ret, wasm.__wbindgen_export, wasm.__wbindgen_export2);
    const len1 = WASM_VECTOR_LEN;
    getDataViewMemory0().setInt32(arg0 + 4 * 1, len1, true);
    getDataViewMemory0().setInt32(arg0 + 4 * 0, ptr1, true);
}
export function __wbg___wbindgen_is_function_fcda5e3902d732fe(arg0) {
    const ret = typeof(getObject(arg0)) === 'function';
    return ret;
}
export function __wbg___wbindgen_is_object_edb6b15aa3afe12e(arg0) {
    const val = getObject(arg0);
    const ret = typeof(val) === 'object' && val !== null;
    return ret;
}
export function __wbg___wbindgen_is_string_c4f7cb494a2a21f1(arg0) {
    const ret = typeof(getObject(arg0)) === 'string';
    return ret;
}
export function __wbg___wbindgen_is_undefined_8c687d0b90d5b524(arg0) {
    const ret = getObject(arg0) === undefined;
    return ret;
}
export function __wbg___wbindgen_string_get_92ab86bb19cbc12f(arg0, arg1) {
    const obj = getObject(arg1);
    const ret = typeof(obj) === 'string' ? obj : undefined;
    var ptr1 = isLikeNone(ret) ? 0 : passStringToWasm0(ret, wasm.__wbindgen_export, wasm.__wbindgen_export2);
    var len1 = WASM_VECTOR_LEN;
    getDataViewMemory0().setInt32(arg0 + 4 * 1, len1, true);
    getDataViewMemory0().setInt32(arg0 + 4 * 0, ptr1, true);
}
export function __wbg___wbindgen_throw_5d9e815e6fdf150f(arg0, arg1) {
    throw new Error(getStringFromWasm0(arg0, arg1));
}
export function __wbg__wbg_cb_unref_997e73d32238e655(arg0) {
    getObject(arg0)._wbg_cb_unref();
}
export function __wbg_abort_03f8c5804715cb9a(arg0, arg1) {
    getObject(arg0).abort(getObject(arg1));
}
export function __wbg_abort_76dea11221098ae5(arg0) {
    getObject(arg0).abort();
}
export function __wbg_addEventListener_ca7d80a9d782e9ac() { return handleError(function (arg0, arg1, arg2, arg3) {
    getObject(arg0).addEventListener(getStringFromWasm0(arg1, arg2), getObject(arg3));
}, arguments); }
export function __wbg_append_8e87c13f0f08f8cd() { return handleError(function (arg0, arg1, arg2, arg3, arg4) {
    getObject(arg0).append(getStringFromWasm0(arg1, arg2), getStringFromWasm0(arg3, arg4));
}, arguments); }
export function __wbg_arrayBuffer_06f3da76f071d37f() { return handleError(function (arg0) {
    const ret = getObject(arg0).arrayBuffer();
    return addHeapObject(ret);
}, arguments); }
export function __wbg_body_9ee03724e9ad0639(arg0) {
    const ret = getObject(arg0).body;
    return isLikeNone(ret) ? 0 : addHeapObject(ret);
}
export function __wbg_buffer_4a989bded7035f57(arg0) {
    const ret = getObject(arg0).buffer;
    return addHeapObject(ret);
}
export function __wbg_byobRequest_f161fc37241dd3d4(arg0) {
    const ret = getObject(arg0).byobRequest;
    return isLikeNone(ret) ? 0 : addHeapObject(ret);
}
export function __wbg_byteLength_0ddb1795e2c7e689(arg0) {
    const ret = getObject(arg0).byteLength;
    return ret;
}
export function __wbg_byteOffset_46eb015f52b6ad7d(arg0) {
    const ret = getObject(arg0).byteOffset;
    return ret;
}
export function __wbg_call_6bcf8d3e20937e46() { return handleError(function (arg0, arg1, arg2) {
    const ret = getObject(arg0).call(getObject(arg1), getObject(arg2));
    return addHeapObject(ret);
}, arguments); }
export function __wbg_cancel_c076350a7e8954be(arg0) {
    const ret = getObject(arg0).cancel();
    return addHeapObject(ret);
}
export function __wbg_catch_e2134ef6dcdb69ed(arg0, arg1) {
    const ret = getObject(arg0).catch(getObject(arg1));
    return addHeapObject(ret);
}
export function __wbg_clearTimeout_1daad5c6ee4fcd3b(arg0) {
    const ret = clearTimeout(takeObject(arg0));
    return addHeapObject(ret);
}
export function __wbg_clearTimeout_47a40e3be01ed7a3() { return handleError(function (arg0, arg1) {
    getObject(arg0).clearTimeout(takeObject(arg1));
}, arguments); }
export function __wbg_close_22882088c136df25() { return handleError(function (arg0) {
    getObject(arg0).close();
}, arguments); }
export function __wbg_close_8b609460dd26e367() { return handleError(function (arg0) {
    getObject(arg0).close();
}, arguments); }
export function __wbg_close_a009f540ff811039() { return handleError(function (arg0) {
    getObject(arg0).close();
}, arguments); }
export function __wbg_code_0589939084228780(arg0) {
    const ret = getObject(arg0).code;
    return ret;
}
export function __wbg_code_6bc89190cbffee9e(arg0) {
    const ret = getObject(arg0).code;
    return ret;
}
export function __wbg_connection_new(arg0) {
    const ret = Connection.__wrap(arg0);
    return addHeapObject(ret);
}
export function __wbg_crypto_38df2bab126b63dc(arg0) {
    const ret = getObject(arg0).crypto;
    return addHeapObject(ret);
}
export function __wbg_data_aa7ba49b34c0d883(arg0) {
    const ret = getObject(arg0).data;
    return addHeapObject(ret);
}
export function __wbg_debug_d3d0e490f96087b4(arg0, arg1) {
    var v0 = getArrayJsValueFromWasm0(arg0, arg1);
    wasm.__wbindgen_export4(arg0, arg1 * 4, 4);
    console.debug(...(v0));
}
export function __wbg_done_cffed884d87aa22e(arg0) {
    const ret = getObject(arg0).done;
    return ret;
}
export function __wbg_endpoint_new(arg0) {
    const ret = Endpoint.__wrap(arg0);
    return addHeapObject(ret);
}
export function __wbg_enqueue_6cb545d22db14f33() { return handleError(function (arg0, arg1) {
    getObject(arg0).enqueue(getObject(arg1));
}, arguments); }
export function __wbg_entries_f9de04c09a57314e(arg0) {
    const ret = getObject(arg0).entries();
    return addHeapObject(ret);
}
export function __wbg_error_2509b4a5fa2a453c(arg0, arg1) {
    var v0 = getArrayJsValueFromWasm0(arg0, arg1);
    wasm.__wbindgen_export4(arg0, arg1 * 4, 4);
    console.error(...(v0));
}
export function __wbg_error_757e9472f8410341(arg0, arg1) {
    let deferred0_0;
    let deferred0_1;
    try {
        deferred0_0 = arg0;
        deferred0_1 = arg1;
        console.error(getStringFromWasm0(arg0, arg1));
    } finally {
        wasm.__wbindgen_export4(deferred0_0, deferred0_1, 1);
    }
}
export function __wbg_fetch_7a37768ab67c5bd8(arg0) {
    const ret = fetch(getObject(arg0));
    return addHeapObject(ret);
}
export function __wbg_fetch_920242d59bac2026(arg0, arg1) {
    const ret = getObject(arg0).fetch(getObject(arg1));
    return addHeapObject(ret);
}
export function __wbg_getRandomValues_436a51d0629d84e1() { return handleError(function (arg0, arg1) {
    globalThis.crypto.getRandomValues(getArrayU8FromWasm0(arg0, arg1));
}, arguments); }
export function __wbg_getRandomValues_c44a50d8cfdaebeb() { return handleError(function (arg0, arg1) {
    getObject(arg0).getRandomValues(getObject(arg1));
}, arguments); }
export function __wbg_getReader_9facd4f899beac89() { return handleError(function (arg0) {
    const ret = getObject(arg0).getReader();
    return addHeapObject(ret);
}, arguments); }
export function __wbg_get_989d0a1309644f2b() { return handleError(function (arg0, arg1) {
    const ret = Reflect.get(getObject(arg0), getObject(arg1));
    return addHeapObject(ret);
}, arguments); }
export function __wbg_get_b1f0ab13c737f856(arg0, arg1) {
    const ret = getObject(arg0)[arg1 >>> 0];
    return addHeapObject(ret);
}
export function __wbg_get_done_a668aa62d81fad70(arg0) {
    const ret = getObject(arg0).done;
    return isLikeNone(ret) ? 0xFFFFFF : ret ? 1 : 0;
}
export function __wbg_get_unchecked_363572bdd397d473(arg0, arg1) {
    const ret = getObject(arg0)[arg1 >>> 0];
    return addHeapObject(ret);
}
export function __wbg_get_value_6c62a77c168d825a(arg0) {
    const ret = getObject(arg0).value;
    return addHeapObject(ret);
}
export function __wbg_has_464f8b9416279d65() { return handleError(function (arg0, arg1) {
    const ret = Reflect.has(getObject(arg0), getObject(arg1));
    return ret;
}, arguments); }
export function __wbg_headers_2594464ff62969f3(arg0) {
    const ret = getObject(arg0).headers;
    return addHeapObject(ret);
}
export function __wbg_instanceof_ArrayBuffer_d4ff01f8247925ae(arg0) {
    let result;
    try {
        result = getObject(arg0) instanceof ArrayBuffer;
    } catch (_) {
        result = false;
    }
    const ret = result;
    return ret;
}
export function __wbg_instanceof_Blob_38df052cf775f822(arg0) {
    let result;
    try {
        result = getObject(arg0) instanceof Blob;
    } catch (_) {
        result = false;
    }
    const ret = result;
    return ret;
}
export function __wbg_instanceof_Response_6366a785e400039b(arg0) {
    let result;
    try {
        result = getObject(arg0) instanceof Response;
    } catch (_) {
        result = false;
    }
    const ret = result;
    return ret;
}
export function __wbg_instanceof_Uint8Array_598adc0fef426aa8(arg0) {
    let result;
    try {
        result = getObject(arg0) instanceof Uint8Array;
    } catch (_) {
        result = false;
    }
    const ret = result;
    return ret;
}
export function __wbg_isArray_5674713bb7b79043(arg0) {
    const ret = Array.isArray(getObject(arg0));
    return ret;
}
export function __wbg_length_31bdaf014f5fbde2(arg0) {
    const ret = getObject(arg0).length;
    return ret;
}
export function __wbg_length_4e1adc0d42e23620(arg0) {
    const ret = getObject(arg0).length;
    return ret;
}
export function __wbg_log_c62f48ee85b1639e(arg0, arg1) {
    var v0 = getArrayJsValueFromWasm0(arg0, arg1);
    wasm.__wbindgen_export4(arg0, arg1 * 4, 4);
    console.log(...(v0));
}
export function __wbg_message_d6ab3d8a5aedce1c(arg0, arg1) {
    const ret = getObject(arg1).message;
    const ptr1 = passStringToWasm0(ret, wasm.__wbindgen_export, wasm.__wbindgen_export2);
    const len1 = WASM_VECTOR_LEN;
    getDataViewMemory0().setInt32(arg0 + 4 * 1, len1, true);
    getDataViewMemory0().setInt32(arg0 + 4 * 0, ptr1, true);
}
export function __wbg_msCrypto_bd5a034af96bcba6(arg0) {
    const ret = getObject(arg0).msCrypto;
    return addHeapObject(ret);
}
export function __wbg_new_0afe64b4dc16ab74() { return handleError(function () {
    const ret = new Headers();
    return addHeapObject(ret);
}, arguments); }
export function __wbg_new_1da3429bc3c4541c(arg0) {
    const ret = new Uint8Array(getObject(arg0));
    return addHeapObject(ret);
}
export function __wbg_new_227d7c05414eb861() {
    const ret = new Error();
    return addHeapObject(ret);
}
export function __wbg_new_82926b2a4d30e175() { return handleError(function (arg0, arg1) {
    const ret = new WebSocket(getStringFromWasm0(arg0, arg1));
    return addHeapObject(ret);
}, arguments); }
export function __wbg_new_a32a1ab6c6655abe(arg0, arg1) {
    const ret = new Error(getStringFromWasm0(arg0, arg1));
    return addHeapObject(ret);
}
export function __wbg_new_baa0a0207935dd43() { return handleError(function () {
    const ret = new AbortController();
    return addHeapObject(ret);
}, arguments); }
export function __wbg_new_bebc3f4757acf305() {
    const ret = new Object();
    return addHeapObject(ret);
}
export function __wbg_new_ffa92086ea89f79c() {
    const ret = new Array();
    return addHeapObject(ret);
}
export function __wbg_new_from_slice_4ee02165f9de919e(arg0, arg1) {
    const ret = new Uint8Array(getArrayU8FromWasm0(arg0, arg1));
    return addHeapObject(ret);
}
export function __wbg_new_typed_6f8b0d724fe26c07(arg0, arg1) {
    try {
        var state0 = {a: arg0, b: arg1};
        var cb0 = (arg0, arg1) => {
            const a = state0.a;
            state0.a = 0;
            try {
                return __wasm_bindgen_func_elem_14554(a, state0.b, arg0, arg1);
            } finally {
                state0.a = a;
            }
        };
        const ret = new Promise(cb0);
        return addHeapObject(ret);
    } finally {
        state0.a = 0;
    }
}
export function __wbg_new_with_byte_offset_and_length_492c969e8b5da8a4(arg0, arg1, arg2) {
    const ret = new Uint8Array(getObject(arg0), arg1 >>> 0, arg2 >>> 0);
    return addHeapObject(ret);
}
export function __wbg_new_with_into_underlying_sink_2596343f9b6c8e58(arg0) {
    const ret = new WritableStream(IntoUnderlyingSink.__wrap(arg0));
    return addHeapObject(ret);
}
export function __wbg_new_with_into_underlying_source_fd904252f385f59c(arg0, arg1) {
    const ret = new ReadableStream(IntoUnderlyingSource.__wrap(arg0), takeObject(arg1));
    return addHeapObject(ret);
}
export function __wbg_new_with_length_5ffeddb9d9fbb96f(arg0) {
    const ret = new Uint8Array(arg0 >>> 0);
    return addHeapObject(ret);
}
export function __wbg_new_with_str_and_init_2f31a77deda127fd() { return handleError(function (arg0, arg1, arg2) {
    const ret = new Request(getStringFromWasm0(arg0, arg1), getObject(arg2));
    return addHeapObject(ret);
}, arguments); }
export function __wbg_new_with_str_sequence_9ab4875494df9d99() { return handleError(function (arg0, arg1, arg2) {
    const ret = new WebSocket(getStringFromWasm0(arg0, arg1), getObject(arg2));
    return addHeapObject(ret);
}, arguments); }
export function __wbg_next_f31ecb8646d2c605() { return handleError(function (arg0) {
    const ret = getObject(arg0).next();
    return addHeapObject(ret);
}, arguments); }
export function __wbg_node_84ea875411254db1(arg0) {
    const ret = getObject(arg0).node;
    return addHeapObject(ret);
}
export function __wbg_now_d1fb6650485d7f3e() {
    const ret = Date.now();
    return ret;
}
export function __wbg_now_e7c6795a7f81e10f(arg0) {
    const ret = getObject(arg0).now();
    return ret;
}
export function __wbg_performance_3fcf6e32a7e1ed0a(arg0) {
    const ret = getObject(arg0).performance;
    return addHeapObject(ret);
}
export function __wbg_process_44c7a14e11e9f69e(arg0) {
    const ret = getObject(arg0).process;
    return addHeapObject(ret);
}
export function __wbg_protocol_b76b26f89befc411(arg0, arg1) {
    const ret = getObject(arg1).protocol;
    const ptr1 = passStringToWasm0(ret, wasm.__wbindgen_export, wasm.__wbindgen_export2);
    const len1 = WASM_VECTOR_LEN;
    getDataViewMemory0().setInt32(arg0 + 4 * 1, len1, true);
    getDataViewMemory0().setInt32(arg0 + 4 * 0, ptr1, true);
}
export function __wbg_prototypesetcall_ae9f5e7459250748(arg0, arg1, arg2) {
    Uint8Array.prototype.set.call(getArrayU8FromWasm0(arg0, arg1), getObject(arg2));
}
export function __wbg_push_bfdf956ba476f65b(arg0, arg1) {
    const ret = getObject(arg0).push(getObject(arg1));
    return ret;
}
export function __wbg_queueMicrotask_85c90f6987555d65(arg0) {
    const ret = getObject(arg0).queueMicrotask;
    return addHeapObject(ret);
}
export function __wbg_queueMicrotask_f6a1fa10b81d1fc0(arg0) {
    queueMicrotask(getObject(arg0));
}
export function __wbg_randomFillSync_6c25eac9869eb53c() { return handleError(function (arg0, arg1) {
    getObject(arg0).randomFillSync(takeObject(arg1));
}, arguments); }
export function __wbg_read_31091533ffadf971(arg0) {
    const ret = getObject(arg0).read();
    return addHeapObject(ret);
}
export function __wbg_readyState_83df235b27cf257f(arg0) {
    const ret = getObject(arg0).readyState;
    return ret;
}
export function __wbg_reason_9b593bf440970929(arg0, arg1) {
    const ret = getObject(arg1).reason;
    const ptr1 = passStringToWasm0(ret, wasm.__wbindgen_export, wasm.__wbindgen_export2);
    const len1 = WASM_VECTOR_LEN;
    getDataViewMemory0().setInt32(arg0 + 4 * 1, len1, true);
    getDataViewMemory0().setInt32(arg0 + 4 * 0, ptr1, true);
}
export function __wbg_releaseLock_1538945f5f183d9f(arg0) {
    getObject(arg0).releaseLock();
}
export function __wbg_removeEventListener_a14fb03179f66dcd() { return handleError(function (arg0, arg1, arg2, arg3) {
    getObject(arg0).removeEventListener(getStringFromWasm0(arg1, arg2), getObject(arg3));
}, arguments); }
export function __wbg_require_b4edbdcf3e2a1ef0() { return handleError(function () {
    const ret = module.require;
    return addHeapObject(ret);
}, arguments); }
export function __wbg_resolve_35ec7e0c6af4c82c(arg0) {
    const ret = Promise.resolve(getObject(arg0));
    return addHeapObject(ret);
}
export function __wbg_respond_83a71686e927ca32() { return handleError(function (arg0, arg1) {
    getObject(arg0).respond(arg1 >>> 0);
}, arguments); }
export function __wbg_send_2bc0d66d884817ad() { return handleError(function (arg0, arg1, arg2) {
    getObject(arg0).send(getStringFromWasm0(arg1, arg2));
}, arguments); }
export function __wbg_send_af811d92e7aea5c4() { return handleError(function (arg0, arg1, arg2) {
    getObject(arg0).send(getArrayU8FromWasm0(arg1, arg2));
}, arguments); }
export function __wbg_setTimeout_6613a51400c1bf9f() { return handleError(function (arg0, arg1, arg2) {
    const ret = getObject(arg0).setTimeout(takeObject(arg1), arg2);
    return addHeapObject(ret);
}, arguments); }
export function __wbg_setTimeout_b4a9096784635514(arg0, arg1) {
    const ret = setTimeout(getObject(arg0), arg1);
    return addHeapObject(ret);
}
export function __wbg_set_5f2ad37e5e02dc7b(arg0, arg1, arg2) {
    getObject(arg0).set(getArrayU8FromWasm0(arg1, arg2));
}
export function __wbg_set_a377297433dfea63() { return handleError(function (arg0, arg1, arg2) {
    const ret = Reflect.set(getObject(arg0), getObject(arg1), getObject(arg2));
    return ret;
}, arguments); }
export function __wbg_set_binaryType_f88804219cea0f9e(arg0, arg1) {
    getObject(arg0).binaryType = __wbindgen_enum_BinaryType[arg1];
}
export function __wbg_set_body_f39cee72c74a5b02(arg0, arg1) {
    getObject(arg0).body = getObject(arg1);
}
export function __wbg_set_cache_6e8c35a5ed76edb1(arg0, arg1) {
    getObject(arg0).cache = __wbindgen_enum_RequestCache[arg1];
}
export function __wbg_set_credentials_bf1d3e014213a571(arg0, arg1) {
    getObject(arg0).credentials = __wbindgen_enum_RequestCredentials[arg1];
}
export function __wbg_set_handle_event_8e892f11ab732c99(arg0, arg1) {
    getObject(arg0).handleEvent = getObject(arg1);
}
export function __wbg_set_headers_31d373f68f28bf76(arg0, arg1) {
    getObject(arg0).headers = getObject(arg1);
}
export function __wbg_set_high_water_mark_089e3476522036ad(arg0, arg1) {
    getObject(arg0).highWaterMark = arg1;
}
export function __wbg_set_method_82e6c3c083da0734(arg0, arg1, arg2) {
    getObject(arg0).method = getStringFromWasm0(arg1, arg2);
}
export function __wbg_set_mode_f7e56ed768d0ade0(arg0, arg1) {
    getObject(arg0).mode = __wbindgen_enum_RequestMode[arg1];
}
export function __wbg_set_name_6e2a5da46a9ae1e7(arg0, arg1, arg2) {
    getObject(arg0).name = getStringFromWasm0(arg1, arg2);
}
export function __wbg_set_onclose_97aab74a1c2662f7(arg0, arg1) {
    getObject(arg0).onclose = getObject(arg1);
}
export function __wbg_set_onerror_88cb2134dca3aba2(arg0, arg1) {
    getObject(arg0).onerror = getObject(arg1);
}
export function __wbg_set_onmessage_0f0d391465909a45(arg0, arg1) {
    getObject(arg0).onmessage = getObject(arg1);
}
export function __wbg_set_onopen_e91e64af99b7966d(arg0, arg1) {
    getObject(arg0).onopen = getObject(arg1);
}
export function __wbg_set_referrer_13cf56bbccbb2ceb(arg0, arg1, arg2) {
    getObject(arg0).referrer = getStringFromWasm0(arg1, arg2);
}
export function __wbg_set_referrer_policy_dac1caa6e937479a(arg0, arg1) {
    getObject(arg0).referrerPolicy = __wbindgen_enum_ReferrerPolicy[arg1];
}
export function __wbg_set_signal_f4b32f40f19786f4(arg0, arg1) {
    getObject(arg0).signal = getObject(arg1);
}
export function __wbg_signal_45367c6c2255877a(arg0) {
    const ret = getObject(arg0).signal;
    return addHeapObject(ret);
}
export function __wbg_stack_3b0d974bbf31e44f(arg0, arg1) {
    const ret = getObject(arg1).stack;
    const ptr1 = passStringToWasm0(ret, wasm.__wbindgen_export, wasm.__wbindgen_export2);
    const len1 = WASM_VECTOR_LEN;
    getDataViewMemory0().setInt32(arg0 + 4 * 1, len1, true);
    getDataViewMemory0().setInt32(arg0 + 4 * 0, ptr1, true);
}
export function __wbg_static_accessor_GLOBAL_8eb4cd83130a11a0() {
    const ret = typeof global === 'undefined' ? null : global;
    return isLikeNone(ret) ? 0 : addHeapObject(ret);
}
export function __wbg_static_accessor_GLOBAL_THIS_1e7044f654e934db() {
    const ret = typeof globalThis === 'undefined' ? null : globalThis;
    return isLikeNone(ret) ? 0 : addHeapObject(ret);
}
export function __wbg_static_accessor_SELF_d8b50611246a6d92() {
    const ret = typeof self === 'undefined' ? null : self;
    return isLikeNone(ret) ? 0 : addHeapObject(ret);
}
export function __wbg_static_accessor_WINDOW_fd0bc376bf0f8b42() {
    const ret = typeof window === 'undefined' ? null : window;
    return isLikeNone(ret) ? 0 : addHeapObject(ret);
}
export function __wbg_status_88ccc72fe7bea621(arg0) {
    const ret = getObject(arg0).status;
    return ret;
}
export function __wbg_subarray_1daff70dde20c145(arg0, arg1, arg2) {
    const ret = getObject(arg0).subarray(arg1 >>> 0, arg2 >>> 0);
    return addHeapObject(ret);
}
export function __wbg_then_7a850dae4493f353(arg0, arg1, arg2) {
    const ret = getObject(arg0).then(getObject(arg1), getObject(arg2));
    return addHeapObject(ret);
}
export function __wbg_then_b830475380919203(arg0, arg1) {
    const ret = getObject(arg0).then(getObject(arg1));
    return addHeapObject(ret);
}
export function __wbg_url_7f0f98717f509a2c(arg0, arg1) {
    const ret = getObject(arg1).url;
    const ptr1 = passStringToWasm0(ret, wasm.__wbindgen_export, wasm.__wbindgen_export2);
    const len1 = WASM_VECTOR_LEN;
    getDataViewMemory0().setInt32(arg0 + 4 * 1, len1, true);
    getDataViewMemory0().setInt32(arg0 + 4 * 0, ptr1, true);
}
export function __wbg_url_f1948b0d7f881e02(arg0, arg1) {
    const ret = getObject(arg1).url;
    const ptr1 = passStringToWasm0(ret, wasm.__wbindgen_export, wasm.__wbindgen_export2);
    const len1 = WASM_VECTOR_LEN;
    getDataViewMemory0().setInt32(arg0 + 4 * 1, len1, true);
    getDataViewMemory0().setInt32(arg0 + 4 * 0, ptr1, true);
}
export function __wbg_value_c227f843d21da141(arg0) {
    const ret = getObject(arg0).value;
    return addHeapObject(ret);
}
export function __wbg_versions_276b2795b1c6a219(arg0) {
    const ret = getObject(arg0).versions;
    return addHeapObject(ret);
}
export function __wbg_view_d8c7b26e4d4650f1(arg0) {
    const ret = getObject(arg0).view;
    return isLikeNone(ret) ? 0 : addHeapObject(ret);
}
export function __wbg_warn_3d4c70cb13f09ea9(arg0, arg1) {
    var v0 = getArrayJsValueFromWasm0(arg0, arg1);
    wasm.__wbindgen_export4(arg0, arg1 * 4, 4);
    console.warn(...(v0));
}
export function __wbg_wasClean_a32ef5f1fd90161e(arg0) {
    const ret = getObject(arg0).wasClean;
    return ret;
}
export function __wbindgen_generic_0000000000000001(arg0, arg1) {
    // Cast intrinsic for `Closure(Closure { owned: true, function: Function { arguments: [Externref], shim_idx: 1662, ret: Unit, inner_ret: Some(Unit) }, mutable: true }) -> Externref`.
    const ret = makeMutClosure(arg0, arg1, __wasm_bindgen_func_elem_5492);
    return addHeapObject(ret);
}
export function __wbindgen_generic_0000000000000002(arg0, arg1) {
    // Cast intrinsic for `Closure(Closure { owned: true, function: Function { arguments: [Externref], shim_idx: 3259, ret: Result(Unit), inner_ret: Some(Result(Unit)) }, mutable: true }) -> Externref`.
    const ret = makeMutClosure(arg0, arg1, __wasm_bindgen_func_elem_14541);
    return addHeapObject(ret);
}
export function __wbindgen_generic_0000000000000003(arg0, arg1) {
    // Cast intrinsic for `Closure(Closure { owned: true, function: Function { arguments: [NamedExternref("CloseEvent")], shim_idx: 450, ret: Unit, inner_ret: Some(Unit) }, mutable: true }) -> Externref`.
    const ret = makeMutClosure(arg0, arg1, __wasm_bindgen_func_elem_2170);
    return addHeapObject(ret);
}
export function __wbindgen_generic_0000000000000004(arg0, arg1) {
    // Cast intrinsic for `Closure(Closure { owned: true, function: Function { arguments: [NamedExternref("MessageEvent")], shim_idx: 2072, ret: Unit, inner_ret: Some(Unit) }, mutable: true }) -> Externref`.
    const ret = makeMutClosure(arg0, arg1, __wasm_bindgen_func_elem_7187);
    return addHeapObject(ret);
}
export function __wbindgen_generic_0000000000000005(arg0, arg1) {
    // Cast intrinsic for `Closure(Closure { owned: true, function: Function { arguments: [], shim_idx: 1621, ret: Unit, inner_ret: Some(Unit) }, mutable: true }) -> Externref`.
    const ret = makeMutClosure(arg0, arg1, __wasm_bindgen_func_elem_5272);
    return addHeapObject(ret);
}
export function __wbindgen_generic_0000000000000006(arg0, arg1) {
    // Cast intrinsic for `Closure(Closure { owned: true, function: Function { arguments: [], shim_idx: 1806, ret: Unit, inner_ret: Some(Unit) }, mutable: true }) -> Externref`.
    const ret = makeMutClosure(arg0, arg1, __wasm_bindgen_func_elem_6408);
    return addHeapObject(ret);
}
export function __wbindgen_generic_0000000000000007(arg0, arg1) {
    // Cast intrinsic for `Closure(Closure { owned: true, function: Function { arguments: [], shim_idx: 1808, ret: Unit, inner_ret: Some(Unit) }, mutable: false }) -> Externref`.
    const ret = makeClosure(arg0, arg1, __wasm_bindgen_func_elem_6464);
    return addHeapObject(ret);
}
export function __wbindgen_generic_0000000000000008(arg0, arg1) {
    // Cast intrinsic for `Closure(Closure { owned: true, function: Function { arguments: [], shim_idx: 3245, ret: Unit, inner_ret: Some(Unit) }, mutable: true }) -> Externref`.
    const ret = makeMutClosure(arg0, arg1, __wasm_bindgen_func_elem_14413);
    return addHeapObject(ret);
}
export function __wbindgen_generic_0000000000000009(arg0) {
    // Cast intrinsic for `F64 -> Externref`.
    const ret = arg0;
    return addHeapObject(ret);
}
export function __wbindgen_generic_000000000000000a(arg0, arg1) {
    // Cast intrinsic for `Ref(Slice(U8)) -> NamedExternref("Uint8Array")`.
    const ret = getArrayU8FromWasm0(arg0, arg1);
    return addHeapObject(ret);
}
export function __wbindgen_generic_000000000000000b(arg0, arg1) {
    // Cast intrinsic for `Ref(String) -> Externref`.
    const ret = getStringFromWasm0(arg0, arg1);
    return addHeapObject(ret);
}
export function __wbindgen_object_clone_ref(arg0) {
    const ret = getObject(arg0);
    return addHeapObject(ret);
}
export function __wbindgen_object_drop_ref(arg0) {
    takeObject(arg0);
}
function __wasm_bindgen_func_elem_5272(arg0, arg1) {
    wasm.__wasm_bindgen_func_elem_5272(arg0, arg1);
}

function __wasm_bindgen_func_elem_6408(arg0, arg1) {
    wasm.__wasm_bindgen_func_elem_6408(arg0, arg1);
}

function __wasm_bindgen_func_elem_6464(arg0, arg1) {
    wasm.__wasm_bindgen_func_elem_6464(arg0, arg1);
}

function __wasm_bindgen_func_elem_14413(arg0, arg1) {
    wasm.__wasm_bindgen_func_elem_14413(arg0, arg1);
}

function __wasm_bindgen_func_elem_5492(arg0, arg1, arg2) {
    wasm.__wasm_bindgen_func_elem_5492(arg0, arg1, addHeapObject(arg2));
}

function __wasm_bindgen_func_elem_2170(arg0, arg1, arg2) {
    wasm.__wasm_bindgen_func_elem_2170(arg0, arg1, addHeapObject(arg2));
}

function __wasm_bindgen_func_elem_7187(arg0, arg1, arg2) {
    wasm.__wasm_bindgen_func_elem_7187(arg0, arg1, addHeapObject(arg2));
}

function __wasm_bindgen_func_elem_14554(arg0, arg1, arg2, arg3) {
    wasm.__wasm_bindgen_func_elem_14554(arg0, arg1, addHeapObject(arg2), addHeapObject(arg3));
}

function __wasm_bindgen_func_elem_14541(arg0, arg1, arg2) {
    try {
        const retptr = wasm.__wbindgen_add_to_stack_pointer(-16);
        wasm.__wasm_bindgen_func_elem_14541(retptr, arg0, arg1, addHeapObject(arg2));
        var r0 = getDataViewMemory0().getInt32(retptr + 4 * 0, true);
        var r1 = getDataViewMemory0().getInt32(retptr + 4 * 1, true);
        if (r1) {
            throw takeObject(r0);
        }
    } finally {
        wasm.__wbindgen_add_to_stack_pointer(16);
    }
}


const __wbindgen_enum_BinaryType = ["blob", "arraybuffer"];


const __wbindgen_enum_ReadableStreamType = ["bytes"];


const __wbindgen_enum_ReferrerPolicy = ["", "no-referrer", "no-referrer-when-downgrade", "origin", "origin-when-cross-origin", "unsafe-url", "same-origin", "strict-origin", "strict-origin-when-cross-origin"];


const __wbindgen_enum_RequestCache = ["default", "no-store", "reload", "no-cache", "force-cache", "only-if-cached"];


const __wbindgen_enum_RequestCredentials = ["omit", "same-origin", "include"];


const __wbindgen_enum_RequestMode = ["same-origin", "no-cors", "cors", "navigate"];
const ConnectionFinalization = (typeof FinalizationRegistry === 'undefined')
    ? { register: () => {}, unregister: () => {} }
    : new FinalizationRegistry(ptr => wasm.__wbg_connection_free(ptr, 1));
const EndpointFinalization = (typeof FinalizationRegistry === 'undefined')
    ? { register: () => {}, unregister: () => {} }
    : new FinalizationRegistry(ptr => wasm.__wbg_endpoint_free(ptr, 1));
const EndpointAddrFinalization = (typeof FinalizationRegistry === 'undefined')
    ? { register: () => {}, unregister: () => {} }
    : new FinalizationRegistry(ptr => wasm.__wbg_endpointaddr_free(ptr, 1));
const IntoUnderlyingByteSourceFinalization = (typeof FinalizationRegistry === 'undefined')
    ? { register: () => {}, unregister: () => {} }
    : new FinalizationRegistry(ptr => wasm.__wbg_intounderlyingbytesource_free(ptr, 1));
const IntoUnderlyingSinkFinalization = (typeof FinalizationRegistry === 'undefined')
    ? { register: () => {}, unregister: () => {} }
    : new FinalizationRegistry(ptr => wasm.__wbg_intounderlyingsink_free(ptr, 1));
const IntoUnderlyingSourceFinalization = (typeof FinalizationRegistry === 'undefined')
    ? { register: () => {}, unregister: () => {} }
    : new FinalizationRegistry(ptr => wasm.__wbg_intounderlyingsource_free(ptr, 1));

function addHeapObject(obj) {
    if (heap_next === heap.length) heap.push(heap.length + 1);
    const idx = heap_next;
    heap_next = heap[idx];

    heap[idx] = obj;
    return idx;
}

function _assertClass(instance, klass) {
    if (!(instance instanceof klass)) {
        throw new Error(`expected instance of ${klass.name}`);
    }
}

const CLOSURE_DTORS = (typeof FinalizationRegistry === 'undefined')
    ? { register: () => {}, unregister: () => {} }
    : new FinalizationRegistry(state => wasm.__wbindgen_export5(state.a, state.b));

function debugString(val) {
    // primitive types
    const type = typeof val;
    if (type == 'number' || type == 'boolean' || val == null) {
        return  `${val}`;
    }
    if (type == 'string') {
        return `"${val}"`;
    }
    if (type == 'symbol') {
        const description = val.description;
        if (description == null) {
            return 'Symbol';
        } else {
            return `Symbol(${description})`;
        }
    }
    if (type == 'function') {
        const name = val.name;
        if (typeof name == 'string' && name.length > 0) {
            return `Function(${name})`;
        } else {
            return 'Function';
        }
    }
    // objects
    if (Array.isArray(val)) {
        const length = val.length;
        let debug = '[';
        if (length > 0) {
            debug += debugString(val[0]);
        }
        for(let i = 1; i < length; i++) {
            debug += ', ' + debugString(val[i]);
        }
        debug += ']';
        return debug;
    }
    // Test for built-in
    const builtInMatches = /\[object ([^\]]+)\]/.exec(toString.call(val));
    let className;
    if (builtInMatches && builtInMatches.length > 1) {
        className = builtInMatches[1];
    } else {
        // Failed to match the standard '[object ClassName]'
        return toString.call(val);
    }
    if (className == 'Object') {
        // we're a user defined class or Object
        // JSON.stringify avoids problems with cycles, and is generally much
        // easier than looping through ownProperties of `val`.
        try {
            return 'Object(' + JSON.stringify(val) + ')';
        } catch (_) {
            return 'Object';
        }
    }
    // errors
    if (val instanceof Error) {
        return `${val.name}: ${val.message}\n${val.stack}`;
    }
    // TODO we could test for more things here, like `Set`s and `Map`s.
    return className;
}

function dropObject(idx) {
    if (idx < 1028) return;
    heap[idx] = heap_next;
    heap_next = idx;
}

function getArrayJsValueFromWasm0(ptr, len) {
    ptr = ptr >>> 0;
    const mem = getDataViewMemory0();
    const result = [];
    for (let i = ptr; i < ptr + 4 * len; i += 4) {
        result.push(takeObject(mem.getUint32(i, true)));
    }
    return result;
}

function getArrayU8FromWasm0(ptr, len) {
    ptr = ptr >>> 0;
    return getUint8ArrayMemory0().subarray(ptr / 1, ptr / 1 + len);
}

let cachedDataViewMemory0 = null;
function getDataViewMemory0() {
    if (cachedDataViewMemory0 === null || cachedDataViewMemory0.buffer.detached === true || (cachedDataViewMemory0.buffer.detached === undefined && cachedDataViewMemory0.buffer !== wasm.memory.buffer)) {
        cachedDataViewMemory0 = new DataView(wasm.memory.buffer);
    }
    return cachedDataViewMemory0;
}

function getStringFromWasm0(ptr, len) {
    return decodeText(ptr >>> 0, len);
}

let cachedUint8ArrayMemory0 = null;
function getUint8ArrayMemory0() {
    if (cachedUint8ArrayMemory0 === null || cachedUint8ArrayMemory0.byteLength === 0) {
        cachedUint8ArrayMemory0 = new Uint8Array(wasm.memory.buffer);
    }
    return cachedUint8ArrayMemory0;
}

function getObject(idx) { return heap[idx]; }

function handleError(f, args) {
    try {
        return f.apply(this, args);
    } catch (e) {
        wasm.__wbindgen_export3(addHeapObject(e));
    }
}

let heap = new Array(1024).fill(undefined);
heap.push(undefined, null, true, false);

let heap_next = heap.length;

function isLikeNone(x) {
    return x === undefined || x === null;
}

function makeClosure(arg0, arg1, f) {
    const state = { a: arg0, b: arg1, cnt: 1 };
    const real = (...args) => {

        // First up with a closure we increment the internal reference
        // count. This ensures that the Rust closure environment won't
        // be deallocated while we're invoking it.
        state.cnt++;
        try {
            return f(state.a, state.b, ...args);
        } finally {
            real._wbg_cb_unref();
        }
    };
    real._wbg_cb_unref = () => {
        if (--state.cnt === 0) {
            wasm.__wbindgen_export5(state.a, state.b);
            state.a = 0;
            CLOSURE_DTORS.unregister(state);
        }
    };
    CLOSURE_DTORS.register(real, state, state);
    return real;
}

function makeMutClosure(arg0, arg1, f) {
    const state = { a: arg0, b: arg1, cnt: 1 };
    const real = (...args) => {

        // First up with a closure we increment the internal reference
        // count. This ensures that the Rust closure environment won't
        // be deallocated while we're invoking it.
        state.cnt++;
        const a = state.a;
        state.a = 0;
        try {
            return f(a, state.b, ...args);
        } finally {
            state.a = a;
            real._wbg_cb_unref();
        }
    };
    real._wbg_cb_unref = () => {
        if (--state.cnt === 0) {
            wasm.__wbindgen_export5(state.a, state.b);
            state.a = 0;
            CLOSURE_DTORS.unregister(state);
        }
    };
    CLOSURE_DTORS.register(real, state, state);
    return real;
}

function passArray8ToWasm0(arg, malloc) {
    const ptr = malloc(arg.length * 1, 1) >>> 0;
    getUint8ArrayMemory0().set(arg, ptr / 1);
    WASM_VECTOR_LEN = arg.length;
    return ptr;
}

function passArrayJsValueToWasm0(array, malloc) {
    const ptr = malloc(array.length * 4, 4) >>> 0;
    const mem = getDataViewMemory0();
    for (let i = 0; i < array.length; i++) {
        mem.setUint32(ptr + 4 * i, addHeapObject(array[i]), true);
    }
    WASM_VECTOR_LEN = array.length;
    return ptr;
}

function passStringToWasm0(arg, malloc, realloc) {
    if (realloc === undefined) {
        const buf = cachedTextEncoder.encode(arg);
        const ptr = malloc(buf.length, 1) >>> 0;
        getUint8ArrayMemory0().subarray(ptr, ptr + buf.length).set(buf);
        WASM_VECTOR_LEN = buf.length;
        return ptr;
    }

    let len = arg.length;
    let ptr = malloc(len, 1) >>> 0;

    const mem = getUint8ArrayMemory0();

    let offset = 0;

    for (; offset < len; offset++) {
        const code = arg.charCodeAt(offset);
        if (code > 0x7F) break;
        mem[ptr + offset] = code;
    }
    if (offset !== len) {
        if (offset !== 0) {
            arg = arg.slice(offset);
        }
        ptr = realloc(ptr, len, len = offset + arg.length * 3, 1) >>> 0;
        const view = getUint8ArrayMemory0().subarray(ptr + offset, ptr + len);
        const ret = cachedTextEncoder.encodeInto(arg, view);

        offset += ret.written;
        ptr = realloc(ptr, len, offset, 1) >>> 0;
    }

    WASM_VECTOR_LEN = offset;
    return ptr;
}

function takeObject(idx) {
    const ret = getObject(idx);
    dropObject(idx);
    return ret;
}

let cachedTextDecoder = new TextDecoder('utf-8', { ignoreBOM: true, fatal: true });
cachedTextDecoder.decode();
const MAX_SAFARI_DECODE_BYTES = 2146435072;
let numBytesDecoded = 0;
function decodeText(ptr, len) {
    numBytesDecoded += len;
    if (numBytesDecoded >= MAX_SAFARI_DECODE_BYTES) {
        cachedTextDecoder = new TextDecoder('utf-8', { ignoreBOM: true, fatal: true });
        cachedTextDecoder.decode();
        numBytesDecoded = len;
    }
    return cachedTextDecoder.decode(getUint8ArrayMemory0().subarray(ptr, ptr + len));
}

const cachedTextEncoder = new TextEncoder();

if (!('encodeInto' in cachedTextEncoder)) {
    cachedTextEncoder.encodeInto = function (arg, view) {
        const buf = cachedTextEncoder.encode(arg);
        view.set(buf);
        return {
            read: arg.length,
            written: buf.length
        };
    };
}

let WASM_VECTOR_LEN = 0;


let wasm;
export function __wbg_set_wasm(val) {
    wasm = val;
}
