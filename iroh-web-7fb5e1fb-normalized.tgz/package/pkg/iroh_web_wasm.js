/* @ts-self-types="./iroh_web_wasm.d.ts" */
import * as wasm from "./iroh_web_wasm_bg.wasm";
import { __wbg_set_wasm } from "./iroh_web_wasm_bg.js";

__wbg_set_wasm(wasm);
wasm.__wbindgen_start();
export {
    Connection, Endpoint, EndpointAddr, IntoUnderlyingByteSource, IntoUnderlyingSink, IntoUnderlyingSource, generateSecretKey, initLogging, secretKeyToId, start
} from "./iroh_web_wasm_bg.js";
