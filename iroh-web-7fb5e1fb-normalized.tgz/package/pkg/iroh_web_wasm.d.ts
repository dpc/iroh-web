/* tslint:disable */
/* eslint-disable */
/**
 * The `ReadableStreamType` enum.
 *
 * *This API requires the following crate features to be activated: `ReadableStreamType`*
 */

export type ReadableStreamType = "bytes";

/**
 * An established QUIC connection to a remote endpoint.
 */
export class Connection {
    private constructor();
    free(): void;
    [Symbol.dispose](): void;
    /**
     * Accepts the next bidirectional stream opened by the remote.
     */
    acceptBi(): Promise<[WritableStream<Uint8Array>, ReadableStream<Uint8Array>]>;
    /**
     * Accepts the next unidirectional (receive-only) stream opened by the remote.
     */
    acceptUni(): Promise<ReadableStream<Uint8Array>>;
    /**
     * The ALPN negotiated for this connection.
     */
    alpn(): Uint8Array;
    /**
     * Closes the connection immediately with an application error code and reason.
     */
    close(error_code: number, reason: Uint8Array): void;
    /**
     * Resolves with an `Error` (carrying a `code` property) describing why the
     * connection closed, once it has closed.
     */
    closed(): Promise<Error>;
    /**
     * Opens a bidirectional stream. Resolves with `[WritableStream, ReadableStream]`.
     */
    openBi(): Promise<[WritableStream<Uint8Array>, ReadableStream<Uint8Array>]>;
    /**
     * Opens a unidirectional (send-only) stream.
     */
    openUni(): Promise<WritableStream<Uint8Array>>;
    /**
     * Hex-encoded id of the remote endpoint.
     */
    remoteId(): string;
}

/**
 * A bound iroh endpoint.
 *
 * All async operations return promises and internally work on a clone of the
 * iroh endpoint, so any number of them can be in flight at once.
 */
export class Endpoint {
    private constructor();
    free(): void;
    [Symbol.dispose](): void;
    /**
     * Waits for the next incoming connection.
     *
     * Resolves with `undefined` once the endpoint is closed. Incoming
     * connections whose handshake fails are logged and skipped.
     */
    accept(): Promise<Connection | undefined>;
    /**
     * The current address (id plus known relay URLs). Call `online()` first
     * to make sure a relay URL is included.
     */
    addr(): EndpointAddr;
    /**
     * Binds an endpoint that resolves peer addresses over HTTPS pkarr without publishing its own.
     */
    static bindLookupOnly(secret_key: Uint8Array | null | undefined, alpns: Uint8Array[], relay_urls?: string[] | null): Promise<Endpoint>;
    /**
     * Binds a new endpoint.
     *
     * * `secret_key`: 32 raw bytes, or `undefined` to generate one.
     * * `alpns`: the ALPNs to accept incoming connections for.
     * * `relay_urls`: relay servers to use. `undefined` selects n0's public
     *   relays plus pkarr address publishing (the `N0` preset). When given,
     *   only those relays are used and no address lookup service is configured.
     */
    static bind(secret_key: Uint8Array | null | undefined, alpns: Uint8Array[], relay_urls?: string[] | null): Promise<Endpoint>;
    /**
     * Closes the endpoint and all its connections.
     */
    close(): Promise<void>;
    /**
     * Connects to a remote endpoint with the given ALPN.
     */
    connect(addr: EndpointAddr, alpn: Uint8Array): Promise<Connection>;
    /**
     * The hex-encoded endpoint id.
     */
    id(): string;
    /**
     * Whether `close()` has been called.
     */
    isClosed(): boolean;
    /**
     * Resolves once the endpoint has a working connection to a home relay.
     */
    online(): Promise<void>;
}

/**
 * An endpoint id plus the relay URLs it can be reached through.
 */
export class EndpointAddr {
    free(): void;
    [Symbol.dispose](): void;
    /**
     * Parses an `endpoint…` ticket string (as produced by [`EndpointAddr::to_ticket`]).
     */
    static fromTicket(ticket: string): EndpointAddr;
    /**
     * The hex-encoded endpoint id.
     */
    id(): string;
    /**
     * Builds an address from a hex endpoint id and zero or more relay URLs.
     */
    constructor(id: string, relay_urls: string[]);
    /**
     * The relay URLs contained in this address.
     */
    relayUrls(): string[];
    /**
     * Serialises this address as a ticket string suitable for QR codes.
     */
    toTicket(): string;
}

export class IntoUnderlyingByteSource {
    private constructor();
    free(): void;
    [Symbol.dispose](): void;
    cancel(): void;
    pull(controller: ReadableByteStreamController): Promise<any>;
    start(controller: ReadableByteStreamController): void;
    readonly autoAllocateChunkSize: number;
    readonly type: ReadableStreamType;
}

export class IntoUnderlyingSink {
    private constructor();
    free(): void;
    [Symbol.dispose](): void;
    abort(reason: any): Promise<any>;
    close(): Promise<any>;
    write(chunk: any): Promise<any>;
}

export class IntoUnderlyingSource {
    private constructor();
    free(): void;
    [Symbol.dispose](): void;
    cancel(): void;
    pull(controller: ReadableStreamDefaultController): Promise<any>;
}

/**
 * Generates a fresh ed25519 secret key and returns its 32 raw bytes.
 */
export function generateSecretKey(): Uint8Array;

/**
 * Routes iroh's `tracing` output to the browser console.
 *
 * `level` is one of `trace`, `debug`, `info`, `warn`, `error` or `off`.
 * Can only be called once per page load.
 */
export function initLogging(level: string): void;

/**
 * Returns the endpoint id (hex-encoded public key) for a 32-byte secret key.
 */
export function secretKeyToId(secret_key: Uint8Array): string;

export function start(): void;
